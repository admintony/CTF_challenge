<?php
error_reporting(0);
$flag = "*********************";
echo "please input a rand_num !";
function create_password($pw_length =  10){
	$randpwd = "";
	for ($i = 0; $i < $pw_length; $i++){
		$randpwd .= chr(mt_rand(100, 200));
	}
	return $randpwd;
}

session_start();

mt_srand(time());

$pwd=create_password();

echo $pwd.'||';    

if($pwd == $_GET['pwd']){
    echo "first";
    if($_SESSION['userLogin']==$_GET['login'])
    	echo "Nice , you get the flag it is ".$flag ;
}else{
	echo "Wrong!";
}

$_SESSION['userLogin']=create_password(32).rand();

?>