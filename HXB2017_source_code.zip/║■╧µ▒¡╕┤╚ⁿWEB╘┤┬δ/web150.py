

import requests,re

#re_pass = re.compile(r'<br>.+||')
url = "http://114.215.138.89:10080/"
while True:
	res = requests.get(url)
	s = res.content[29:-8]
	print s
	resloaction = requests.get("http://127.0.0.1/test.php")
	list = resloaction.content.split(' ')
	if list[0]==s :
		params['login']=list[1]
	params={}
	params['pwd']=s
	#params['login']=s
	resp = requests.get(url,params=params)
	if 'flag' in resp.content :
		print resp.content
		break;
	elif 'Wrong' in resp.content :
		print 'Wrong'
	elif 'first' in resp.content :
		print 'first'
	else :pass
