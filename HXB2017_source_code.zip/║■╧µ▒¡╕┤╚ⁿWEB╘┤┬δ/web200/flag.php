<?php 
$flag="flag{c420fb4054e91944a71ff68f7079b9424e5cba21}"; 
?>
