<?php
include 'common.php';
?>
<center>
<div class="article">
    <h2>Welcome!!</h2>
    <p>
        We let you upload PNG image files and store it!<br/>
    </p>
    <p>
        Get started by <a href="?op=upload">uploading a picture</a>
    </p>
    
</div>
</center>